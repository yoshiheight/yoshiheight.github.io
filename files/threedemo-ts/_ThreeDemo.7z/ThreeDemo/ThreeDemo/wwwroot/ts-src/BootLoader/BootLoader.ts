﻿namespace ThreeDemo {
    /**
     * ブートローダー
     */
    export class BootLoader {
        public static async loadAsync(): Promise<void> {
            await BootLoader.loadScriptsAsync([
                "https://cdn.jsdelivr.net/npm/three@0.116.1/build/three.min.js",
                "/files/threedemo-ts/app/threedemo.js?v=3ad28c9f1d9d4cdfaa9df345781df947",
            ]);
        }

        /**
         * jsファイルの動的読み込み。
         * @param urls
         */
        private static async loadScriptsAsync(urls: string[]): Promise<void> {
            for (let url of urls) {
                await new Promise(resolve => {
                    let scriptElem = document.createElement("script");
                    scriptElem.onload = () => resolve();
                    scriptElem.async = true;
                    scriptElem.src = url;
                    document.body.appendChild(scriptElem);
                });
            }
        }
    }
}
