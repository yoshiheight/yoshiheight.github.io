﻿namespace NekoDemo {
    /**
     * ブートローダー
     */
    export class BootLoader {
        public static async loadAsync(): Promise<void> {
            await BootLoader.loadScriptsAsync([
                "https://cdnjs.cloudflare.com/ajax/libs/pixi.js/4.5.1/pixi.min.js",
                "/files/neko-ts/app/neko.js?v=3c64656ea23f46e7b5fcc404d647e585",
            ]);
        }

        /**
         * jsファイルの動的読み込み。
         * @param urls
         */
        private static async loadScriptsAsync(urls: string[]): Promise<void> {
            for (let url of urls) {
                await new Promise(resolve => {
                    let scriptElem = document.createElement("script");
                    scriptElem.onload = () => resolve();
                    scriptElem.async = true;
                    scriptElem.src = url;
                    document.body.appendChild(scriptElem);
                });
            }
        }
    }
}
